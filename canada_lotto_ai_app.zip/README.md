
# Canada Lotto AI

Une petite application Streamlit pour analyser les tirages (6/49 & Lotto Max) et générer des tickets basés sur les numéros "chauds" et "froids".

## Déploiement sur Streamlit Cloud
1. Créez un compte sur [Streamlit Cloud](https://streamlit.io/cloud).
2. Connectez votre repo GitHub contenant ce code.
3. Choisissez `app.py` comme fichier principal et cliquez sur "Deploy".
